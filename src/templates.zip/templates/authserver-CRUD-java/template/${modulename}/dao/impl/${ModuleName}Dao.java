package ${package}dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import ${package}dao.I${ModuleName}Dao;
import com.primesoft.authserver.tools.util.sql.Sql;
import com.primesoft.framework.core.map.EasyMap;
import com.primesoft.framework.core.pagination.Page;
import com.primesoft.framework.core.pagination.Pageable;
import com.primesoft.framework.orm.jdbc.dao.IPublicDao;

@Component("i${ModuleName}Dao")
public class ${ModuleName}Dao implements I${ModuleName}Dao {

	@Resource
	private IPublicDao iPublicDao;

	@Override
	public Object save(Map<String, Object> data) {
		return iPublicDao.save(TABLE_NAME, data).get("${shortname_}id");
	}

	@Override
	public void deleteAllByCustomerId(Object c_id) {
		iPublicDao.delete(TABLE_NAME, new EasyMap<String, Object>("${shortname_}cid", c_id));
	}

	@Override
	public Page<Map<String, Object>> list(String userId, String blur, String type, Pageable pagination) {
		// TODO 根据用户id判断用户${ch_Name}。系统管理员可以查看和编辑所有模块，其他人只能看其所属客户的模块，且只能修改自己创建的模块
		Sql sql = new Sql(1).select("t.*");
		sql.from(TABLE_NAME).append(" t ");

		if (blur != null && blur.length() > 0) {
			sql.where("(${shortname_}name LIKE ? OR ${shortname_}code LIKE ? )");
			sql.addParam("%" + blur + "%").addParam("%" + blur + "%");
		}

		if (type != null && type.length() > 0) {
			sql.and("${shortname_}type = ?");
			sql.addParam(type);
		}

		sql.ascOrderby("t.${shortname_}ordercode");

		return iPublicDao.findPage(pagination, sql.toString(), sql.getParams());
	}

	@Override
	public Object add(Map<String, Object> module) {
		Map<String, Object> map = iPublicDao.save(TABLE_NAME, module);
		return map.get("${shortname_}id");
	}

	@Override
	public List<Object> add(List<Map<String, Object>> entities) {
		List<Object> ids = new ArrayList<Object>(entities.size());
		for (Map<String, Object> entity : entities) {
			ids.add(this.add(entity));
		}
		return ids;
	}

	@Override
	public void update(Map<String, Object> entity) {
		iPublicDao.update(TABLE_NAME, entity);
	}

	@Override
	public void delete(Map<String, Object> entity) {
		iPublicDao.delete(TABLE_NAME, entity);
	}

	@Override
	public void delete(List<Map<String, Object>> entities) {
		iPublicDao.deleteBatch(TABLE_NAME, entities);
	}

	@Override
	public Map<String, Object> find(String id) {
		return iPublicDao.findOne(TABLE_NAME, new EasyMap<String, Object>("${shortname_}id", id));
	}

	@Override
	public boolean exists(String ${shortname_}id, String field, String value) {
		Sql sql = new Sql(2).select("*").from(TABLE_NAME).where(field + " = ?");
		sql.addParam(value);

		if (${shortname_}id != null) {
			sql.and("${shortname_}id != ?");
			sql.addParam(${shortname_}id);
		}
		return iPublicDao.existBySql(sql.toString(), sql.getParams());
	}

}
