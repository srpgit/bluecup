package ${package}dao;

import java.util.List;
import java.util.Map;

import com.primesoft.framework.core.pagination.Page;
import com.primesoft.framework.core.pagination.Pageable;

public interface I${ModuleName}Dao {
	public static final String TABLE_NAME = "ps_${module_name}";

	public Object save(Map<String, Object> data);

	public void deleteAllByCustomerId(Object c_id);

	Page<Map<String, Object>> list(String userId, String blur, String type, Pageable pagination);

	boolean exists(String moduleId, String field, String value);

	Map<String, Object> find(String id);

	Object add(Map<String, Object> entity);

	List<Object> add(List<Map<String, Object>> entities);

	void delete(Map<String, Object> entity);

	void delete(List<Map<String, Object>> entities);

	void update(Map<String, Object> entity);
}
