package ${package}action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONArray;
import ${package}service.I${ModuleName}Service;
import com.primesoft.authserver.tools.util.MapUtil;
import com.primesoft.authserver.tools.util.PSResult;
import com.primesoft.framework.core.pagination.Page;
import com.primesoft.framework.orm.jdbc.proxy.TransactionProxy;
import com.primesoft.framework.web.webgrid.jqgrid.JqGridUtil;

@Controller
@RequestMapping("/module/${modulename}/")
public class ${ModuleName}Action {
	@Resource
	private I${ModuleName}Service i${ModuleName}Service;

	public I${ModuleName}Service get${ModuleName}Service() {
		return TransactionProxy.createTransactionProxy(i${ModuleName}Service);
	}

	@RequestMapping("listPage")
	public void listPage(HttpServletRequest request, HttpServletResponse response) {
		try {

			String userId = "1";// TODO
			String blur = request.getParameter("blur");
			String type = request.getParameter("type");
			JqGridUtil jqGridUtil = new JqGridUtil(request, response);
			Page<Map<String, Object>> page = get${ModuleName}Service().list(userId, blur, type, jqGridUtil.getPagination());
			jqGridUtil.writePage(page);
		} catch (Exception e) {
			PSResult.failed(e).write(response);
		}
	}

	@RequestMapping("exists")
	public void existsName(HttpServletRequest request, HttpServletResponse response) {
		try {
			String ${shortname_}id = request.getParameter("${shortname_}id");
			String ${shortname_}name = request.getParameter("${shortname_}name");
			
			boolean result = false;
			if (${shortname_}name != null) {
				result = get${ModuleName}Service().existsName(${shortname_}id, ${shortname_}name);
			}
			PSResult.ok(result).write(response);
		} catch (Exception e) {
			PSResult.failed(e).write(response);
		}
	}

	@RequestMapping("find")
	public void find(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id = request.getParameter("${shortname_}id");
			if (id == null || id.length() == 0) {
				throw new IllegalArgumentException("查找${ch_name}信息失败");
			}

			Map<String, Object> entity = get${ModuleName}Service().find(id);
			PSResult.ok(entity).write(response);
		} catch (Exception e) {
			PSResult.failed(e).write(response);
		}
	}

	@RequestMapping("delete")
	public void delete(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<String> ids = JSONArray.parseArray(request.getParameter("ids"), String.class);
			get${ModuleName}Service().delete(ids);
			PSResult.ok("删除成功！").write(response);
		} catch (Exception e) {
			PSResult.failed(e).write(response);
		}
	}

	@RequestMapping("save")
	public void save(HttpServletRequest request, HttpServletResponse response) {
		try {
			// TODO
			String ui_id = "1";
			String c_id = "1";

			String id = request.getParameter("${shortname_}id");

			MapUtil mapUtil = MapUtil.create(request).pickParams("${shortname_}name", "${shortname_}remark", "${shortname_}type", "${shortname_}code", "${shortname_}ordercode").filterEmpty();

			mapUtil.put("${shortname_}cid", c_id);
			mapUtil.put("${shortname_}creator", ui_id);

			Map<String, Object> entity = mapUtil.build();
			I${ModuleName}Service i${ModuleName}Service = this.get${ModuleName}Service();

			boolean isAdd = (id == null || id.length() == 0);
			if (isAdd) {
				entity.put("${shortname_}createtime", new Date());
				id = String.valueOf(i${ModuleName}Service.add(entity));
			} else {
				entity.put("${shortname_}id", id);
				i${ModuleName}Service.update(entity);
			}
			
			PSResult.ok("保存成功！").write(response);
		} catch (Exception e) {
			PSResult.failed(e).write(response);
		}
	}
}
