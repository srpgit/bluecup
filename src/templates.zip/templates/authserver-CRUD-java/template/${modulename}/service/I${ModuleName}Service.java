package ${package}service;

import java.util.List;
import java.util.Map;

import com.primesoft.framework.core.pagination.Page;
import com.primesoft.framework.core.pagination.Pageable;

public interface I${ModuleName}Service {

	Page<Map<String, Object>> list(String userId, String blur, String type, Pageable pagination);

	boolean existsName(String ${shortname_}id, String ${shortname_}name);

	Map<String, Object> find(String id);

	Object add(Map<String, Object> entity);

	void update(Map<String, Object> entity);

	void delete(String id);

	void delete(List<String> ids);
}
