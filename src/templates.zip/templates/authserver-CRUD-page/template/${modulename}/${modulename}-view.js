j$(function() {
	var modal = window.top.j$.ps.bootstrap.modal;
	var disableInteraction = window.top.j$.ps.bootstrap.disableInteraction;

	var typeMap = {
		'0' : '系统${ch_name}',
		'1' : '普通${ch_name}',
	};

	// TODO 根据当前用户的${ch_name}类型来判断，是否显示“系统${ch_name}”
	var sel = j$('#search-type');
	for ( var type in typeMap) {
		var option = j$(document.createElement('option'));
		option.val(type).html(typeMap[type]);
		sel.append(option);
	}

	bindEvt();

	var grid = undefined;
	refreshJqGrid({
		rebuild : true
	});

	resize();

	/*-----------define functions------------*/
	function bindEvt() {
		j$("#btn-add").on("click", function() {
			addOrUpdate("新增${ch_name}");
		});

		j$("#btn-del").click(function() {
			var ids = grid.jqGrid("getGridParam", "selarrrow");
			if (ids.length > 0) {
				j$.ps.bootstrap.alert({
					"content" : "是否删除选中${ch_name}？",
					"side" : "float",
					"type" : "warn",
					"onOk" : function() {
						onDelele(ids, true);
						this.close();
					},
					"onCancel" : true
				});
			}
		});

		j$('#btn-search').click(function() {
			doSearch();
		});

		j$('#search-name').keydown(function(e) {
			if (e.keyCode == '13') {
				doSearch();
			}
		});

		j$(window).resize(resize);
	}

	/**
	 * 刷新表格
	 */
	function refreshJqGrid(postData) {
		// 搜索相关
		var blur = postData['blur'];
		var type = postData['type'];

		var colNames = [ 'id', '操作', '${ch_name}名', '代码', '${ch_name}类型', '创建人', '创建时间', '备注' ];
		var col = [ {
			name : "${shortname_}id",
			index : "${shortname_}id",
			key : true,
			hidden : true,
		}, {
			name : 'oper',
			index : 'oper',
			align : 'center',
			sortable : false,
			width : 120,
			formatter : function(cellValue, options, rowValue) {
				var editSetting = {
					icons : {
						primary : "ui-icon-pencil"
					},
					label : "编辑",
					click : "javascript:onEditModuleClick('" + rowValue.${shortname_}id + "');return false;"
				};
				var removeSetting = {
					icons : {
						primary : "ui-icon-trash"
					},
					label : "删除",
					click : "javascript:onDeleteModuleClick('" + rowValue.${shortname_}id + "');return false;"
				};
				var str = operateFormatter(editSetting, 0);
				str += operateFormatter(removeSetting);
				return str;
			}
		}, {
			name : '${shortname_}name',
			index : '${shortname_}name',
			align : 'center',
			width : 200
		}, {
			name : '${shortname_}code',
			index : '${shortname_}code',
			align : 'center',
			width : 200
		}, {
			name : '${shortname_}type',
			index : '${shortname_}type',
			align : 'center',
			width : 100,
			formatter : function(cellValue) {
				return typeMap[cellValue] || '';
			}
		}, {
			name : '${shortname_}creator',
			index : '${shortname_}creator',
			align : 'center',
			hidden : true,
			width : 100
		}, {
			name : '${shortname_}createtime',
			index : '${shortname_}createtime',
			hidden : true,
			align : 'center',
			width : 100,
			formatter : function(celValue, options, rowValue) {
				return celValue;
			}
		}, {
			name : '${shortname_}remark',
			index : '${shortname_}remark',
			align : 'center',
			width : 300
		} ];

		grid = j$.ps.jqGrid({
			parent : "#div-grid",
			gridId : "grid",
			rebuild : postData.rebuild,
			url : ps.rootPath + "module/${modulename}/listPage.action",
			datatype : "json",
			mtype : "POST",
			postData : {
				"${shortname_}id" : postData['${shortname_}id'],
				'blur' : blur,
				'type' : type
			},
			colNames : colNames,
			colModel : col,
			multiselect : true,
			multiboxonly : true,
			width : j$(window).width() - 2,
			height : 600,
			pager : '#pager',
			sortname : '',
			sortorder : "asc",
			caption : getCaption("${ch_name}列表"),
		});

		j$('#search-name').val(blur);
		j$('#search-type').val(type);
		// 重新绑定事件
		j$('#btn-search').click(function() {
			doSearch();
		});
		j$('#search-name').keydown(function(e) {
			if (e.keyCode == '13') {
				doSearch();
			}
		});

		resize();
	}

	window.onEditModuleClick = function(${shortname_}id) {
		addOrUpdate("编辑${ch_name}", ${shortname_}id);
	};

	window.onDeleteModuleClick = function(${shortname_}id) {
		j$.ps.bootstrap.alert({
			"content" : "是否删除${ch_name}？",
			"type" : "warn",
			"side" : "float",
			"onOk" : function() {
				onDelele([ ${shortname_}id ]);
				this.close();
			},
			"onCancel" : true
		});
	};

	function resize() {
		var w = window.innerWidth;
		var h = window.innerHeight;
		var contentHeight = h - j$('#footer').height() - 2 - 5;
		grid.jqGrid('setGridWidth', w - 12).jqGrid('setGridHeight', contentHeight - 100);
		j$('#content').height(contentHeight);
	}

	function addOrUpdate(title, ${shortname_}id) {
		var addCount = 0;

		var btnClose = j$(" <button type='button' class='btn btn-default'>关闭</button>");
		var btnSave = j$(" <button type='button' class='btn btn-primary'>保存</button>");
		btnClose.click(function() {
			if (${shortname_}id === undefined && addCount > 0) {
				refreshGrid();
			}
			modal.closeWindow("#editPage");
		});
		btnSave.click(function() {
			modal.callMethod("#editPage", "save");
		});

		modal.openWindow({
			id : "editPage",
			closable : false,
			title : title,
			height : 550,
			params : {
				'${shortname_}id' : ${shortname_}id
			},
			width : 550 / 0.618,
			button : j$("<div>").append(btnSave, btnClose),
			url : ps.rootPath + "module/${modulename}/${modulename}-add-modify.html?"
					+ (${shortname_}id ? "${shortname_}id=" + ${shortname_}id : ""),
			returnValue : function(obj) {
				if (${shortname_}id !== undefined) {
					refreshGrid();
					modal.closeWindow("#editPage");
				} else {
					addCount++;
				}
			}
		});
	}

	function onDelele(items, needRefresh) {

		var disHandle = disableInteraction("删除中...", "button", "a").show();

		function deleteCustomer(items, callbacks) {
			j$.ajax({
				"url" : ps.rootPath + "module/${modulename}/delete.action",
				"data" : {
					"ids" : JSON.stringify(items)
				},
				"dataType" : "json",
				"type" : "POST",
				success : function(json) {
					if (json.code == 0) {
						callbacks.success();
					} else {
						callbacks.failed(json.msg);
					}
				},
				error : function(err) {
					callbacks.failed(err);
				}
			});
		}

		var callbacks = {
			"success" : function() {
				disHandle.closeFinal();
				j$.ps.bootstrap.alert("删除成功！", "success");
				refreshGrid();
			},
			"failed" : function(err) {
				disHandle.closeFinal();
				j$.ps.bootstrap.alert(err, "danger");
				refreshGrid();
			}
		};

		deleteCustomer(items, callbacks);

	}

	function refreshGrid() {
		refreshJqGrid({
			rebuild : true
		});
	}

	function doSearch() {
		refreshJqGrid({
			rebuild : true,
			blur : j$('#search-name').val(),
			type : j$('#search-type').val()
		});
	}
});
