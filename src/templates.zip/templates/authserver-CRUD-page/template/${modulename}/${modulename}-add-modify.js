j$(function() {
	var form = j$('#form');
	form.find('#${shortname_}name').focus();

	var addUrl = ps.rootPath + "module/${modulename}/save.action";
	var alertObj = window.top.j$.ps.bootstrap.alert;
	initValidate();
	bindEvt();

	var ${shortname_}id = ps.getParams("${shortname_}id");

	// 父页面注册事件按钮
	parentParams.onRegisterMethod('save', saveFun);

	// 修改，加载${ch_name}信息
	var isModify = !!${shortname_}id;
	if (isModify) {
		j$.ajax({
			url : ps.rootPath + "module/${modulename}/find.action",
			type : "POST",
			dataType : "json",
			data : {
				"${shortname_}id" : ${shortname_}id
			},
			async : false,
			success : function(json) {
				if (json.code == 0) {
					var data = json.content;

					form.find('#${shortname_}id').val(${shortname_}id);
					form.find("#${shortname_}name").val(data.${shortname_}name);
					form.find("#${shortname_}url").val(data.${shortname_}url);
					form.find("#${shortname_}type").val(data.${shortname_}type);
					form.find("#${shortname_}remark").val(data.${shortname_}remark);
				} else {
					alertObj(JSON.stringify(json), "warn");
				}
			},
			error : function(err) {
				alertObj('网络异常，请稍后重试', "warn");
			}
		});
	}

	/*--------------define functions-----------------*/
	function bindEvt() {
	}

	/**
	 * 查询数据库中是否已存在${ch_name}名
	 */
	function exists(field, value) {
		var result = false;
		var data = {};
		data['${shortname_}id'] = ${shortname_}id;
		data[field] = value;
		j$.ajax({
			url : ps.rootPath + "module/${modulename}/exists.action",
			type : "POST",
			dataType : "json",
			data : data,
			async : false,
			success : function(json) {
				if (json.code == 0 && json.content) {
					result = true;
				}
			}
		});
		return result;
	}

	function initValidate() {
		var validate = j$.ps.validate.init({
			info : "over",
			blur : true,
			type : "m",
			id : "validateForm"
		});
		validate.addItem('${shortname_}name', '${ch_name}名称').notNull().notCS().length({
			max : 50
		}).addValidate(function(item) {
			var ${shortname_}name = item.obj.val();
			var result = {};
			result.result = true;
			if (${shortname_}name) {
				result.result = !exists('${shortname_}name',${shortname_}name);
			}
			result.msg = '${ch_name}名称已存在';
			return result;
		});
		validate.addItem('${shortname_}url', '${ch_name}URL').notNull().length({
			max : 50
		});
		validate.addItem('${shortname_}remark', '备注').length({
			max : 500
		});
	}

	function saveFun() {
		var result = j$.ps.validate.getValidate("validateForm").checkAll();
		if (result.err > 0) {
			return false;
		}

		// 防止重复点击
		var infoAlert = j$.ps.bootstrap.disableInteraction("保存中...", "button").useTop(true);
		infoAlert.side = "float";
		infoAlert.show();

		form.ajaxSubmit({
			"dataType" : "json",
			"type" : "POST",
			"url" : addUrl,
			"error" : function(err) {
				infoAlert.closeFinal();
				alertObj(JSON.stringify(err), "warn", "float");
			},
			success : function(data) {
				infoAlert.closeFinal();
				if (data.code === undefined) {
					alertObj(JSON.stringify(data), "warn", "float");
				} else if (data.code != 0) {
					alertObj(data.msg, "warn", "float");
				} else {
					alertObj({
						"beforeClose" : function() {
							parentParams.returnValue(data); // 返回结果
							form.resetForm();// 重置表单
						},
						"type" : "success",
						"content" : j$('<p>').text(isModify ? "修改成功！" : "添加成功", "float")
					});

				}
			}
		});
	}

});