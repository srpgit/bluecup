package ${package}.service;

public interface ${IService} {

}
