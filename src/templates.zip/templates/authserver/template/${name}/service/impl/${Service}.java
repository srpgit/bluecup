package ${package}.service.impl;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import ${package}.dao.${IDao};
import ${package}.service.${IService};

@Service("${iService}")
public class ${Service} implements ${IService} {
	@Resource
	private ${IDao} ${iDao};
}
