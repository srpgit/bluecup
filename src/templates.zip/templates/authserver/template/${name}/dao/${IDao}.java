package ${package}.dao;

public interface ${IDao} {
	String TABLE_NAME = "ps_${name}";
}
