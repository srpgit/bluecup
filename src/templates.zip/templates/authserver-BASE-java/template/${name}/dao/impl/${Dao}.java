package ${package}dao.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import ${package}dao.${IDao};
import com.primesoft.framework.orm.jdbc.dao.IPublicDao;

@Component("${iDao}")
public class ${Dao} implements ${IDao} {

	@Resource
	private IPublicDao iPublicDao;

}
