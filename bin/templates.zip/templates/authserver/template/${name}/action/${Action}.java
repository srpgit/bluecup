package ${package}action;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ${package}service.${IService};

@Controller
@RequestMapping("/module/${name}/")
public class ${Action} {
	@Resource
	private ${IService} ${iService};
}
