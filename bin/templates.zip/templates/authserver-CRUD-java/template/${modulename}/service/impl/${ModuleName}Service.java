package ${package}service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import ${package}dao.I${ModuleName}Dao;
import ${package}service.I${ModuleName}Service;
import com.primesoft.framework.core.map.EasyMap;
import com.primesoft.framework.core.pagination.Page;
import com.primesoft.framework.core.pagination.Pageable;

@Service
public class ${ModuleName}Service implements I${ModuleName}Service {
	private static final Logger LOGGER = Logger.getLogger(${ModuleName}Service.class);

	@Resource
	private I${ModuleName}Dao i${ModuleName}Dao;

	@Override
	public Page<Map<String, Object>> list(String userId, String blur, String type, Pageable pagination) {
		try {
			return i${ModuleName}Dao.list(userId, blur, type, pagination);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException("查询失败");
		}
	}

	@Override
	public boolean existsName(String ${shortname_}id, String ${shortname_}name) {
		try {
			return i${ModuleName}Dao.exists(${shortname_}id, "${shortname_}name", ${shortname_}name);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException("查询失败");
		}
	}

	@Override
	public Object add(Map<String, Object> entity) {
		try {
			return i${ModuleName}Dao.add(entity);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException("保存失败");
		}
	}

	@Override
	public void delete(String id) {
		try {
			i${ModuleName}Dao.delete(new EasyMap<String, Object>().append("${shortname_}id", id));
		} catch (Exception e1) {
			LOGGER.error(e1);
			throw new RuntimeException("删除失败！");
		}
	}

	@Override
	public void delete(List<String> ids) {
		try {
			for (String id : ids) {
				this.delete(id);
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> find(String id) {
		try {
			return i${ModuleName}Dao.find(id);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException("查询失败");
		}
	}

	@Override
	public void update(Map<String, Object> entity) {
		try {
			i${ModuleName}Dao.update(entity);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new RuntimeException("保存失败");
		}
	}
}
